
<?php
/**
 * Returns the list of policies.
 */
require 'database.php';

$department = [];
$sql = "SELECT * FROM department";
// $sql="select * from users LEFT join department on users.department_id = department.department_id Left Join user_roles a ON users.role_id = a.role_id Order by user_enabled asc";

if($result = mysqli_query($con,$sql))
{
  $i = 0;
  while($row = mysqli_fetch_assoc($result))
  {
    $department[$i]['department_code']    =   $row['department_code'];
    $department[$i]['department_name']     =   $row['department_name'];
    $i++;
  }

  echo json_encode($department);
}
else
{
  http_response_code(404);
}
?>