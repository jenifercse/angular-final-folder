
//  @Author : jenifer
// @date : 4 dec 2019
// @desc : login component 

import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormBuilder,FormArray } from '@angular/forms';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
returnUrl;
  constructor(private app:ApiService,private router:Router,public authService: AuthService) { }
LoginForm : FormGroup=new FormGroup({
	username:new FormControl(),
	password:new FormControl()
});

  ngOnInit() {
  
  }
 public signup():void
		 {
		 	if(this.LoginForm.controls['username'].value=="admin" &&
		      this.LoginForm.controls['password'].value=="admin123")
		    {
		  		alert("login");
		    	this.router.navigate(['./admin']);
        		
		    }
		    else
		    {
		     
		      alert("Invalid login");
		    }
		 }
}
