import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormBuilder,FormArray } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
	 SERVER_URL = "http://localhost/angular-online-test/backend/api/adduser.php";
 UserForm: FormGroup = new FormGroup({
 		user_fname: new FormControl(),
          user_lname: new FormControl(),
          user_name: new FormControl(),
          user_password: new FormControl(),
 });
  constructor(private fb: FormBuilder, private httpClient: HttpClient) { }

  ngOnInit() {
  	 this.UserForm = this.fb.group
      ({
         user_fname: new FormControl(),
          user_lname: new FormControl(),
          user_name: new FormControl(),
          user_password: new FormControl()
      });
  }

}
