
//  @Author : jenifer
// @date : 4 dec 2019
// @desc : adminmodule 

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin/admin.component';
import { UsersComponent } from './users/users.component';
import { ExamsComponent } from './exams/exams.component';
import { DepartmentsComponent } from './departments/departments.component';
import { ResultsComponent } from './results/results.component';
import { QuestionsComponent } from './questions/questions.component';
import { AdduserComponent } from './adduser/adduser.component';

import {ReactiveFormsModule,FormsModule} from '@angular/forms';


@NgModule({
  declarations: [AdminComponent, UsersComponent, ExamsComponent, DepartmentsComponent, ResultsComponent, QuestionsComponent, AdduserComponent],
  imports: [
    CommonModule,
    AdminRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class AdminModule { }
