import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from '../../api.service';
import { HttpClient } from '@angular/common/http';
import { Questions} from  '../../policy';
import { FormControl,FormGroup } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {
  @ViewChild('myForm') formValues; // Added this
contactForm: FormGroup = new FormGroup({
	question:new FormControl(),
	option1:new FormControl(),
	option2:new FormControl(),
	option3:new FormControl(),
	option4:new FormControl(),
	answer:new FormControl()
});
question: Questions[];

  constructor(private service:ApiService,private router:Router) { }

  ngOnInit() {
  	
  }
 create()
 {
   alert("really want to insert?");
 	console.log(this.contactForm.value);
 	this.service.addquestion(this.contactForm.value).subscribe((x)=>{
 		console.log(x);
     
 		// this.route.navigate('./viewquestion');

 	});
 }
 clear(x)
 {
    this.formValues.resetForm(); // Added thiss
 }
 
}
