import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../api.service';
import { HttpClient } from '@angular/common/http';
import { Exam } from  '../../policy';

@Component({
  selector: 'app-exams',
  templateUrl: './exams.component.html',
  styleUrls: ['./exams.component.css']
})
export class ExamsComponent implements OnInit {
exams:  Exam[];
  constructor(private service:ApiService) { }

  ngOnInit() {
  	this.service.readExam().subscribe((exams:  Exam[])=>{
      this.exams = exams;
      console.log(this.exams);
    })
  }

}
