import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../api.service';
import { HttpClient } from '@angular/common/http';
import { Policy } from  '../../policy';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
 policies:  Policy[];
  constructor(private service:ApiService) { }

  ngOnInit() {
  	this.service.readPolicies().subscribe((policies: Policy[])=>{
      this.policies = policies;
      console.log(this.policies);
    })
  }

// createOrUpdatePolicy(form){
//     if(this.selectedPolicy && this.selectedPolicy.id){
//       form.value.id = this.selectedPolicy.id;
//       this.service.updatePolicy(form.value).subscribe((policy: Policy)=>{
//         console.log("Policy updated" , policy);
//       });
//     }
//     else{

//       this.service.createPolicy(form.value).subscribe((policy: Policy)=>{
//         console.log("Policy created, ", policy);
//       });
//     }

//   }

//   selectPolicy(policy: Policy){
//     this.selectedPolicy = policy;
//   }

  deletePolicy(id){
    alert("really want to delete?");
    this.service.deletePolicy(id).subscribe((policy: Policy)=>{
      console.log("Policy deleted, ", policy);
    });
  }

}
