
//  @Author : jenifer
// @date : 4 dec 2019
// @desc : master routing 

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminModule } from './admin/admin.module';


const routes: Routes = [
							{
								path : '',
								loadChildren: () => import('./login/login.module').then(m => m.LoginModule)
							},
							{
								path : 'admin',
								loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule)
							}
													];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
